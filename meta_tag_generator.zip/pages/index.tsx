import { Button, TextField, Typography, Box, Paper } from '@mui/material';
import { useState, useEffect } from 'react';
import { metaQuery } from '@/CustomHooks/cms.query.hooks';
import PreviewTab from '@/Components/previewTabs/previewTab';
import CopySection from '@/Components/CopySection/Copysection';

export default function Home() {
  const urlFormat = /^(https?:\/\/[^\s$.?#].[^\s]*)$/;
  const [url, setUrl] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [metaTags, setMetaTags] = useState<any>(null);
  const [isQueryEnabled, setIsQueryEnabled] = useState<boolean>(false);
  const [editableMetaTags, setEditableMetaTags] = useState<any>(null);
  const { data, isError, isLoading } = metaQuery(url, isQueryEnabled);
  interface HTMLInputElement {
    value: any
  }
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.target.value;
    if (!urlFormat.test(input)) {
      setError('Invalid URL format');
    } else {
      setError('');
    }
    setUrl(input);
    setMetaTags(null);
  };

  const handleCheckWebsite = () => {
    if (!url || error) {
      return;
    }
    setIsQueryEnabled(true);
  };

  useEffect(() => {
    if (data) {
      setMetaTags(data);
      setEditableMetaTags(data);
    }
  }, [data]);

  const handleEditableInputChange = (e: React.ChangeEvent<HTMLInputElement>, key: string) => {
    const { value }: any = e.target;
    setEditableMetaTags((prevTags: any) => ({
      ...prevTags,
      [key]: value,
    }));
  };

  const renderMetaTags = () => {
    if (!metaTags) return null;

    return (
      <Box
        sx={{
          padding: '10px',
          backgroundColor: '#2d2d2d',
          color: '#f8f8f2',
          borderRadius: '5px',
          fontFamily: 'monospace',
          fontSize: '14px',
          lineHeight: '1.5',
          width: "600px"
        }}
      >
        <Typography variant="h5" gutterBottom>
          <b>Scraped Meta Tags:</b>
        </Typography>

        <Typography sx={{ color: '#6272a4' }}>{`<!-- HTML Meta Tags -->`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<title>${metaTags.title || 'No title'}</title>`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta name="description" content="${metaTags.description || ''}" />`}</Typography>

        <Typography sx={{ color: '#6272a4', marginTop: '10px' }}>{`<!-- Facebook Meta Tags -->`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta property="og:url" content="${metaTags['og:url'] || ''}" />`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta property="og:type" content="${metaTags['og:type'] || ''}" />`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta property="og:title" content="${metaTags['og:title'] || ''}" />`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta property="og:description" content="${metaTags['og:description'] || ''}" />`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta property="og:image" content="${metaTags['og:image'] || ''}" />`}</Typography>

        <Typography sx={{ color: '#6272a4', marginTop: '10px' }}>{`<!-- Twitter Meta Tags -->`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta name="twitter:card" content="${metaTags['twitter:card'] || ''}" />`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta name="twitter:url" content="${metaTags['twitter:url'] || ''}" />`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta name="twitter:title" content="${metaTags['twitter:title'] || ''}" />`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta name="twitter:description" content="${metaTags['twitter:description'] || ''}" />`}</Typography>
        <Typography sx={{ paddingLeft: '10px' }}>{`<meta name="twitter:image" content="${metaTags['twitter:image'] || ''}" />`}</Typography>
        <CopySection metaTags={metaTags} />
      </Box>
    );
  };

  const renderEditableFields = () => {
    if (!editableMetaTags) return null;


    return (
      <Box sx={{ marginTop: '20px', width: "600px" }}>
        <Typography variant="h6">Edit Meta Tags:</Typography>
        <TextField
          label="Title"
          value={editableMetaTags.title || ''}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleEditableInputChange(e, 'title')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Description"
          value={editableMetaTags.description || ''}
          onChange={(e) => handleEditableInputChange(e, 'description')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Open Graph URL"
          value={editableMetaTags['og:url'] || ''}
          onChange={(e) => handleEditableInputChange(e, 'og:url')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Open Graph Title"
          value={editableMetaTags['og:title'] || ''}
          onChange={(e) => handleEditableInputChange(e, 'og:title')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Open Graph Description"
          value={editableMetaTags['og:description'] || ''}
          onChange={(e) => handleEditableInputChange(e, 'og:description')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Open Graph Image"
          value={editableMetaTags['og:image'] || ''}
          onChange={(e) => handleEditableInputChange(e, 'og:image')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Twitter Card"
          value={editableMetaTags['twitter:card'] || ''}
          onChange={(e) => handleEditableInputChange(e, 'twitter:card')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Twitter URL"
          value={editableMetaTags['twitter:url'] || ''}
          onChange={(e) => handleEditableInputChange(e, 'twitter:url')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Twitter Title"
          value={editableMetaTags['twitter:title'] || ''}
          onChange={(e) => handleEditableInputChange(e, 'twitter:title')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Twitter Description"
          value={editableMetaTags['twitter:description'] || ''}
          onChange={(e) => handleEditableInputChange(e, 'twitter:description')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
        <TextField
          label="Twitter Image"
          value={editableMetaTags['twitter:image'] || ''}
          onChange={(e) => handleEditableInputChange(e, 'twitter:image')}
          fullWidth
          sx={{ marginBottom: '10px' }}
        />
      </Box>
    );
  };

  return (
    <div style={{ padding: '20px', minHeight: '70vh' }}>
      <div style={{ marginBottom: "50px" }}>
        <Typography variant="h5" gutterBottom style={{ textAlign: "center", marginBottom: "-10px" }}>
          Try the
        </Typography>
        <Typography variant="h2" gutterBottom style={{ textAlign: "center" }}>
          <b>Free Meta Tag Generator</b>
        </Typography>
        <Typography variant="h5" gutterBottom style={{ textAlign: "center", marginTop: "-20px" }}>
          and Preview all Open Graph meta tag in one place
        </Typography>
      </div>

      <TextField
        value={url}
        onChange={handleInputChange}
        label="Enter website URL"
        fullWidth
        error={!!error}
        helperText={error}
        style={{ marginBottom: '20px' }}
      />
      <Button
        variant="contained"
        color="primary"
        onClick={handleCheckWebsite}
        disabled={!url || !!error}
        style={{ marginBottom: '20px' }}
      >
        Check Website
      </Button>

      {isLoading && <p>Loading meta tags...</p>}
      {isError && <p style={{ color: 'red' }}>Error fetching meta tags</p>}

      {metaTags && (
        <Paper
          elevation={3}
          sx={{
            padding: '20px',
            marginTop: '20px',
            backgroundColor: '#ffffff',
            borderRadius: '8px',
            boxShadow: '0px 3px 6px rgba(0, 0, 0, 0.1)',
          }}
        >
          <div style={{ display: "flex", flexDirection: "row", justifyContent: "space-between" }}>
            {renderEditableFields()}
            {renderMetaTags()}
            <PreviewTab metaTags={metaTags} />
          </div>

        </Paper>
      )}
    </div>
  );
}
